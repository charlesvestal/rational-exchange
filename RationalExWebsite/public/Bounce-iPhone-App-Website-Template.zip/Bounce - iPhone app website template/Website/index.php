<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<meta name="description" content=" "><!-- <<<<   Add a brief decription of your app -->

<title>Bounce - iPhone App Template</title>

<!----  User-Scalable = NO  ---->
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />

<!----  CSS  ---->
<link href="site/css/styles.css" rel="stylesheet" type="text/css" />

<link href='http://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>

</head>

<body onload="MM_preloadImages('site/images/header_background.jpg')">

<div class="loading_screen"></div>

<div class="inner_page">

<div class="header">

  <div class="inner_wrapper">
  
    <div class="iphone_hand"></div>
    
    <div class="header_right_column">
    
    <h1>Keep in touch with the people that matter most...</h1>
    
    <a href="#" class="appstore_button"></a>
    
    <a href="#" class="google_play_button"></a>
    
    </div>
  
  </div>

</div>

<div class="section_one">

  <div class="inner_wrapper">
  
    <div class="section_one_header">
    
    <h2>With you when it matters...</h2>
    
    <p>Phasellus sagittis, sem at vulputate elementum, dui ante lobortis erat, lacinia ante quis ante. Donec nec urna pellentesque sapien vehicula semper. Integer accumsan massa nec dictum lobortis. Aenean rhoncus consectetur ornare.</p>
    
    </div>
    
    <div class="section_one_iphones_wrapper">
    
      <div class="section_one_iphone_one"></div>
      
      <div class="section_one_iphone_two"></div>
      
      <div class="section_one_iphone_three"></div>
      
    </div>
    
 </div> 
 
</div>



<div class="features_section">

  <div class="inner_wrapper">
  
  <h3>Some features that make our app awesome</h3>
  
	<ul class="features_list">

    <lI>
      <div class="feature_icon location"></div>
      <p class="feature_title">Location Enabled</p>
      <p>Sem at vulputate elementum, dui ante lobortis erat, lacinia ante quis sapien vehicula ante.</p>
    </lI>


    <lI>
      <div class="feature_icon cloud"></div>
      <p class="feature_title">Cloud Based</p>
      <p>Sem at vulputate elementum, dui ante lobortis erat, lacinia ante quis sapien vehicula ante.</p>
    </lI>


    <lI>
      <div class="feature_icon storage"></div>
      <p class="feature_title">Secure Storage</p>
      <p>Sem at vulputate elementum, dui ante lobortis erat, lacinia ante quis sapien vehicula ante.</p>
    </lI>


    <lI>
      <div class="feature_icon music"></div>
      <p class="feature_title">Custom Playlists</p>
      <p>Sem at vulputate elementum, dui ante lobortis erat, lacinia ante quis sapien vehicula ante.</p>
    </lI>


    <lI>
      <div class="feature_icon docs"></div>
      <p class="feature_title">Clear Documentation</p>
      <p>Sem at vulputate elementum, dui ante lobortis erat, lacinia ante quis sapien vehicula ante.</p>
    </lI>


    <lI>
      <div class="feature_icon stats"></div>
      <p class="feature_title">Live Stats</p>
      <p>Sem at vulputate elementum, dui ante lobortis erat, lacinia ante quis sapien vehicula ante.</p>
    </lI>
  
  </ul>




 </div> 
</div>


<div class="team_section">
  <div class="inner_wrapper">
    <h4>Meet the team</h4>
    <div class="team_member_wrapper">
      <div class="team_member_avatar">
        <img src="site/images/team_member_1.jpg" width="128" height="128" alt=""/>
      </div>
      <p class="team_member_name">Team Member</p>
      <p class="team_member_position">Developer</p>
    
      <div class="team_member_social_icons">
      <a href="#" class="twitter_icon"></a>
      <a href="#" class="dribbble_icon"></a>
      <a href="#" class="fb_icon"></a>
      </div>
    
    </div>
    
    <div class="team_member_wrapper">
      <div class="team_member_avatar">
        <img src="site/images/team_member_2.jpg" width="128" height="128" alt=""/>
      </div>
      <p class="team_member_name">Team Member</p>
      <p class="team_member_position">Developer</p>
    
      <div class="team_member_social_icons">
      <a href="#" class="twitter_icon"></a>
      <a href="#" class="dribbble_icon"></a>
      <a href="#" class="fb_icon"></a>
      </div>
    
    </div>
    
    <div class="team_member_wrapper">
      <div class="team_member_avatar">
        <img src="site/images/team_member_3.jpg" width="128" height="128" alt=""/>
      </div>
      <p class="team_member_name">Team Member</p>
      <p class="team_member_position">Developer</p>
    
      <div class="team_member_social_icons">
      <a href="#" class="twitter_icon"></a>
      <a href="#" class="dribbble_icon"></a>
      <a href="#" class="fb_icon"></a>
      </div>
    
    </div>

 </div> 
</div>


<div class="final_cta_section">
 <div class="inner_wrapper">
  <h4>Download our app</h4>
    <div class="final_cta_store_buttons_wrapper">
      <a href="#" class="appstore_button"></a>
      <a href="#" class="google_play_button"></a>
    </div>
 </div> 

</div>


<div class="footer">
  <div class="inner_wrapper">
    <div class="footer_social_icons">
      <a href="#" class="twitter_icon"></a>
      <a href="#" class="fb_icon"></a>
      <a href="#" class="appstore_icon"></a>
    </div>
     
    <p>AppName</p>
    <p class="copyright">© 2014</p>
  </div>

</div>

</div>
<!----  Scripts ---->
<script src="site/js/jquery-1.9.1.min.js"></script>
<script src="site/js/site.js"></script>


<!----  Preload Images  ---->
<script>
function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
</script>


</body>
</html>